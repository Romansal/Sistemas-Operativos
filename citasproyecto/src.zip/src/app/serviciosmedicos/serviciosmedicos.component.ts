import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-serviciosmedicos',
  templateUrl: './serviciosmedicos.component.html',
  styleUrls: ['./serviciosmedicos.component.css']
})
export class ServiciosmedicosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
