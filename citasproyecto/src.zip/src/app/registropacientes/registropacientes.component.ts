import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registropacientes',
  templateUrl: './registropacientes.component.html',
  styleUrls: ['./registropacientes.component.css']
})
export class RegistropacientesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
