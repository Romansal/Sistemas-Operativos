import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guardardatos',
  templateUrl: './guardardatos.component.html',
  styleUrls: ['./guardardatos.component.css']
})
export class GuardardatosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
