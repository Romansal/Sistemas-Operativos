import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-impresiondatos',
  templateUrl: './impresiondatos.component.html',
  styleUrls: ['./impresiondatos.component.css']
})
export class ImpresiondatosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
